﻿using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System;

using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System;
using System.Drawing;
using System.Drawing.Imaging;

namespace PongoProng
{
    internal class IntroScreen : GameWindow
    {
        private bool gameStarted = false;

        public IntroScreen() : base(800, 600, new OpenTK.Graphics.GraphicsMode(32, 24, 0, 4))
        {
            VSync = VSyncMode.On;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            GL.ClearColor(Color.Black);
            GL.Enable(EnableCap.Texture2D);
            // Configure OpenGL settings for rendering
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();
            GL.Ortho(0, Width, Height, 0, -1, 1);
            GL.MatrixMode(MatrixMode.Modelview);
        }

        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            base.OnUpdateFrame(e);

            if (Keyboard.GetState().IsKeyDown(Key.Enter))
            {
                gameStarted = true;
                this.Exit();
            }
        }

        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);

            GL.Clear(ClearBufferMask.ColorBufferBit);

            // Draw the ASCII art
            string asciiArt = @"
                                                                                                             
                                                                                                    
                .:::::::::::::::.                              .:!:::. ... .:::::.                  
             :::.                .:!:                      .!:.  ..  . . ..  . ...::.               
           :::                       .!:                .!:.  . . .. .. ...  .  ....::              
          ::.                 .         :!.            ... .  .. ...  . . ..  . . .. :!             
         .::                  .         . :!         :...  ..  . . .. .. . .  .. ... .:.            
         .::                            .  :!.      ## .. . .  .. . .  ..  ..  . . ...!.            
          ::                                :!     !#!  ..   .  ...  . .. . .  .. . ::!             
           ::                          .    :!.    !#..   .. .. .... .  ..   .  ... .:              
            .!.                             :!:    !#:.. ...  .  ...  .  ... .. ....                
              .!:              .      .  . :!!!    ###::   ..  . . .. .  ..   . !#:                 
                 :!:       .  .          :!!!!!.   #####! . .  .. . .  : . ..##:                    
                    .:!!:            :!!!.   .!:. :#.   .###!:  ... .. !###!                        
                           :!!!!!!!!:     .:::. ..... .       #######!                              
                                  .:!!!: !::: ..........  :####.                                    
                                        .!!:: .:......:::.                                          
                                         :!!:..:::::::::.                                           
                                            .:!:::::::.                                             
                                           !!!!:.  ......                                           
                                        .!!!!::      ......                                         
                                      :!!!!:.          :......                                      
                                    !!!::::              ::::::.                                    
                                    .#!!:................. .#.                                      
                                  ..........::::::::::...........                                                        
            ";

            DrawAsciiArt(asciiArt);

            SwapBuffers();
        }

        private void DrawAsciiArt(string art)
        {
            GL.Color3(Color.White);
            // Set up bitmap font rendering or texture-based rendering here
            // This is a placeholder method; you'll need to implement actual text rendering
            // For simplicity, this code assumes you will handle text rendering separately
        }
    }
}
