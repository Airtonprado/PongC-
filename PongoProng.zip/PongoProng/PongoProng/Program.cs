﻿using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;

namespace PongoProng
{
    internal class Program : GameWindow
    {
        enum GameState
        {
            Menu,
            Playing
        }

        GameState estadoAtual = GameState.Menu;

        int xDaBola = 0;
        int yDaBola = 0;
        int TamanhodaBola = 20;
        int velocidadeDaBolaEmX = 4;
        int velocidadeDaBolaEmY = 4;

        int ydojogador1 = 0;
        int ydojogador2 = 0;

        int pontosJogador1 = 0;
        int pontosJogador2 = 0;

        int Xdojogador1()
        {
            return -ClientSize.Width / 2 + larguraDosJogadores() / 2;
        }

        int Xdojogador2()
        {
            return ClientSize.Width / 2 - larguraDosJogadores() / 2;
        }

        int larguraDosJogadores()
        {
            return TamanhodaBola;
        }

        int alturaDosJogadores()
        {
            return 4 * TamanhodaBola;
        }

        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            if (estadoAtual == GameState.Playing)
            {
                xDaBola += velocidadeDaBolaEmX;
                yDaBola += velocidadeDaBolaEmY;

                // Verifica colisão com os jogadores
                if (xDaBola + TamanhodaBola / 2 > Xdojogador2() - larguraDosJogadores() / 2 &&
                    yDaBola - TamanhodaBola / 2 < ydojogador2 + alturaDosJogadores() / 2 &&
                    yDaBola + TamanhodaBola / 2 > ydojogador2 - alturaDosJogadores() / 2)
                {
                    velocidadeDaBolaEmX = -velocidadeDaBolaEmX;
                }

                if (xDaBola - TamanhodaBola / 2 < Xdojogador1() + larguraDosJogadores() / 2 &&
                    yDaBola - TamanhodaBola / 2 < ydojogador1 + alturaDosJogadores() / 2 &&
                    yDaBola + TamanhodaBola / 2 > ydojogador1 - alturaDosJogadores() / 2)
                {
                    velocidadeDaBolaEmX = -velocidadeDaBolaEmX;
                }

                // Verifica colisão com as bordas e atualiza pontuação
                if (yDaBola + TamanhodaBola / 2 > ClientSize.Height / 2 ||
                    yDaBola - TamanhodaBola / 2 < -ClientSize.Height / 2)
                {
                    velocidadeDaBolaEmY = -velocidadeDaBolaEmY;
                }

                if (xDaBola < -ClientSize.Width / 2)
                {
                    pontosJogador2++;
                    xDaBola = 0;
                    yDaBola = 0;
                }
                else if (xDaBola > ClientSize.Width / 2)
                {
                    pontosJogador1++;
                    xDaBola = 0;
                    yDaBola = 0;
                }

                // Comandos do jogador
                if (Keyboard.GetState().IsKeyDown(Key.W))
                {
                    ydojogador1 += 5;
                }

                if (Keyboard.GetState().IsKeyDown(Key.S))
                {
                    ydojogador1 -= 5;
                }

                if (Keyboard.GetState().IsKeyDown(Key.Up))
                {
                    ydojogador2 += 5;
                }

                if (Keyboard.GetState().IsKeyDown(Key.Down))
                {
                    ydojogador2 -= 5;
                }
            }
            else if (estadoAtual == GameState.Menu)
            {
                if (Keyboard.GetState().IsKeyDown(Key.Enter))
                {
                    estadoAtual = GameState.Playing;
                }
            }
        }

        protected override void OnRenderFrame(FrameEventArgs e)
        {
            GL.Viewport(0, 0, Width, Height);
            Matrix4 projection = Matrix4.CreateOrthographic(ClientSize.Width, ClientSize.Height, 0.0f, 1.0f);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref projection);

            GL.Clear(ClearBufferMask.ColorBufferBit);

            if (estadoAtual == GameState.Playing)
            {
                // Desenha a bola e os jogadores
                DesenharRetangulo(xDaBola, yDaBola, TamanhodaBola, TamanhodaBola, 1.0f, 1.0f, 1.0f);
                DesenharRetangulo(Xdojogador1(), ydojogador1, larguraDosJogadores(), alturaDosJogadores(), 1.0f, 0.0f, 0.0f);
                DesenharRetangulo(Xdojogador2(), ydojogador2, larguraDosJogadores(), alturaDosJogadores(), 0.0f, 0.0f, 1.0f);

                // Desenha o placar
                DesenharTexto(-ClientSize.Width / 2 + 50, ClientSize.Height / 2 - 30, $"Jogador 1: {pontosJogador1}", 1.0f, 1.0f, 1.0f);
                DesenharTexto(ClientSize.Width / 2 - 150, ClientSize.Height / 2 - 30, $"Jogador 2: {pontosJogador2}", 1.0f, 1.0f, 1.0f);
            }
            else if (estadoAtual == GameState.Menu)
            {
                // Desenha a tela inicial
                DesenharTexto(0, ClientSize.Height / 2 - 30, "PongoProng", 1.0f, 1.0f, 1.0f);
                DesenharTexto(0, ClientSize.Height / 2 - 60, "Pressione Enter para começar", 1.0f, 1.0f, 1.0f);

                // Desenha uma representação simples das raquetes e da bola
                DesenharRetangulo(0, 0, larguraDosJogadores(), alturaDosJogadores(), 1.0f, 0.0f, 0.0f); // Raquete esquerda
                DesenharRetangulo(0, 0, larguraDosJogadores(), alturaDosJogadores(), 0.0f, 0.0f, 1.0f); // Raquete direita
                DesenharRetangulo(0, 0, TamanhodaBola, TamanhodaBola, 1.0f, 1.0f, 1.0f); // Bola
            }

            SwapBuffers();
        }

        void DesenharRetangulo(int x, int y, int largura, int altura, float r, float g, float b)
        {
            GL.Color3(r, g, b);
            GL.Begin(PrimitiveType.Quads);
            GL.Vertex2(x - largura / 2, y - altura / 2);
            GL.Vertex2(x + largura / 2, y - altura / 2);
            GL.Vertex2(x + largura / 2, y + altura / 2);
            GL.Vertex2(x - largura / 2, y + altura / 2);
            GL.End();
        }

        // Método para desenhar texto na tela
        void DesenharTexto(float x, float y, string texto, float r, float g, float b)
        {
            GL.Color3(r, g, b);
            // Aqui você deve implementar a renderização de texto
            // Uma abordagem comum é usar bitmap fonts ou uma biblioteca externa para isso
        }
        static void Main()
        {
            //using (var intro = new IntroScreen())
            // {
            //intro.Run(60.0);
            // }

            using (var game = new Program())
            {
                game.Run(60.0);
            }
        }

    }
}





/*
 * 
 * codigo sem placar mas funcional
 * 
 * 
 using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using OpenTK.Graphics;

namespace PongoProng
{
    internal class Program : GameWindow
    {
        int xDaBola = 0;
        int yDaBola = 0;
        int TamanhodaBola = 20;
        int velocidadeDaBolaEmX = 4;
        int velocidadeDaBolaEmY = 4;

        int ydojogador1 = 0;
        int ydojogador2 = 0;

        int pontosJogador1 = 0;
        int pontosJogador2 = 0;

        int Xdojogador1()
        {
            return -ClientSize.Width / 2 + larguraDosJogadores() / 2;
        }

        int Xdojogador2()
        {
            return ClientSize.Width / 2 - larguraDosJogadores() / 2;
        }

        int larguraDosJogadores()
        {
            return TamanhodaBola;
        }

        int alturaDosJogadores()
        {
            return 4 * TamanhodaBola;
        }

        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            xDaBola += velocidadeDaBolaEmX;
            yDaBola += velocidadeDaBolaEmY;

            // Verifica colisão com os jogadores
            if (xDaBola + TamanhodaBola / 2 > Xdojogador2() - larguraDosJogadores() / 2 &&
                yDaBola - TamanhodaBola / 2 < ydojogador2 + alturaDosJogadores() / 2 &&
                yDaBola + TamanhodaBola / 2 > ydojogador2 - alturaDosJogadores() / 2)
            {
                velocidadeDaBolaEmX = -velocidadeDaBolaEmX;
            }

            if (xDaBola - TamanhodaBola / 2 < Xdojogador1() + larguraDosJogadores() / 2 &&
                yDaBola - TamanhodaBola / 2 < ydojogador1 + alturaDosJogadores() / 2 &&
                yDaBola + TamanhodaBola / 2 > ydojogador1 - alturaDosJogadores() / 2)
            {
                velocidadeDaBolaEmX = -velocidadeDaBolaEmX;
            }

            // Verifica colisão com as bordas e atualiza pontuação
            if (yDaBola + TamanhodaBola / 2 > ClientSize.Height / 2 ||
                yDaBola - TamanhodaBola / 2 < -ClientSize.Height / 2)
            {
                velocidadeDaBolaEmY = -velocidadeDaBolaEmY;
            }

            if (xDaBola < -ClientSize.Width / 2)
            {
                pontosJogador2++;
                xDaBola = 0;
                yDaBola = 0;
            }
            else if (xDaBola > ClientSize.Width / 2)
            {
                pontosJogador1++;
                xDaBola = 0;
                yDaBola = 0;
            }

            // Comandos do jogador
            if (Keyboard.GetState().IsKeyDown(Key.W))
            {
                ydojogador1 += 5;
            }

            if (Keyboard.GetState().IsKeyDown(Key.S))
            {
                ydojogador1 -= 5;
            }

            if (Keyboard.GetState().IsKeyDown(Key.Up))
            {
                ydojogador2 += 5;
            }

            if (Keyboard.GetState().IsKeyDown(Key.Down))
            {
                ydojogador2 -= 5;
            }
        }

        protected override void OnRenderFrame(FrameEventArgs e)
        {
            GL.Viewport(0, 0, Width, Height);
            Matrix4 projection = Matrix4.CreateOrthographic(ClientSize.Width, ClientSize.Height, 0.0f, 1.0f);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref projection);

            GL.Clear(ClearBufferMask.ColorBufferBit);

            // Desenha a bola e os jogadores
            DesenharRetangulo(xDaBola, yDaBola, TamanhodaBola, TamanhodaBola, 1.0f, 1.0f, 1.0f);
            DesenharRetangulo(Xdojogador1(), ydojogador1, larguraDosJogadores(), alturaDosJogadores(), 1.0f, 0.0f, 0.0f);
            DesenharRetangulo(Xdojogador2(), ydojogador2, larguraDosJogadores(), alturaDosJogadores(), 0.0f, 0.0f, 1.0f);

            // Desenha o placar
            DesenharTexto(-ClientSize.Width / 2 + 50, ClientSize.Height / 2 - 30, $"Jogador 1: {pontosJogador1}", 1.0f, 1.0f, 1.0f);
            DesenharTexto(ClientSize.Width / 2 - 150, ClientSize.Height / 2 - 30, $"Jogador 2: {pontosJogador2}", 1.0f, 1.0f, 1.0f);

            SwapBuffers();
        }

        void DesenharRetangulo(int x, int y, int largura, int altura, float r, float g, float b)
        {
            GL.Color3(r, g, b);
            GL.Begin(PrimitiveType.Quads);
            GL.Vertex2(x - largura / 2, y - altura / 2);
            GL.Vertex2(x + largura / 2, y - altura / 2);
            GL.Vertex2(x + largura / 2, y + altura / 2);
            GL.Vertex2(x - largura / 2, y + altura / 2);
            GL.End();
        }

        // Método para desenhar texto na tela
        void DesenharTexto(float x, float y, string texto, float r, float g, float b)
        {
            GL.Color3(r, g, b);
            // Aqui você deve implementar a renderização de texto
            // Uma abordagem comum é usar bitmap fonts ou uma biblioteca externa para isso
        }

        static void Main()
        {
            using (var game = new Program())
            {
                game.Run(60.0);
            }
        }
    }
}
*/